﻿require.config({
    urlArgs: 't=637612596206859442'
});