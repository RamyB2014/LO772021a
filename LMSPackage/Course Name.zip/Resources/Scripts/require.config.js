﻿require.config({
    urlArgs: 't=637612605520729730'
});