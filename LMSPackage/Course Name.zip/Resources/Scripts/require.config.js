﻿require.config({
    urlArgs: 't=637612605200545402'
});